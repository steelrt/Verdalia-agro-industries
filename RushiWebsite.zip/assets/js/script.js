
document.addEventListener('DOMContentLoaded', () => {
    console.log('Rushi Website Loaded');
});
